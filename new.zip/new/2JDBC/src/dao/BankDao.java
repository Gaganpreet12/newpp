package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import bean.BankBean;
import bean.BankTransaction;

public class BankDao implements BankDaoI {

	Connection con = null;
	PreparedStatement preparedStatement = null;
	ResultSet resultSet = null;
	BankBean bank = new BankBean();

	/*
	 * Check Account is Exist or Not
	 */
	@Override
	public boolean checkAccount(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;
		String query = "SELECT * FROM BankDetails WHERE accountno = ?";
		con = BankDB.getConnection();
		preparedStatement = con.prepareStatement(query);
		preparedStatement.setLong(1, accNo);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			res = false;
		} else {
			res = true;
		}
		return res;
	}

	/*
	 * Insert Data to DB
	 */
	@Override
	public void InsertData(long accNo, BankBean bean) throws ClassNotFoundException, SQLException {
		con = BankDB.getConnection();
		preparedStatement = con.prepareStatement("INSERT INTO BankDetails VALUES(?,?,?,?,?,?)");
		preparedStatement.setString(1, bean.getName());
		preparedStatement.setLong(2, bean.getAccNo());
		preparedStatement.setLong(3, bean.getPin());
		preparedStatement.setString(4, bean.getAddress());
		preparedStatement.setString(5, bean.getPhone());
		preparedStatement.setInt(6, bean.getBalance());
		int r = preparedStatement.executeUpdate();
		if (r == 0) {
			System.out.println("Not inserted");
		} else {
			System.out.println("Value inserted");
		}
	}

	/*
	 * Update Data to DB
	 */
	@Override
	public void updateData(BankBean bean) throws ClassNotFoundException, SQLException {
		con = BankDB.getConnection();
		preparedStatement = con.prepareStatement("UPDATE BankDetails SET BALANCE = ? WHERE accountno = ?");
		preparedStatement.setInt(1, bean.getBalance());
		preparedStatement.setLong(2, bean.getAccNo());
		int r = preparedStatement.executeUpdate();
		if (r == 0) {
			System.out.println("Cannot update");
		} else {
			System.out.println("Updated");
		}
	}

	/*
	 * Get Account Details
	 */
	@Override
	public BankBean getAccountDetails(long accNo) throws ClassNotFoundException, SQLException {
		boolean res = false;
		String query = "SELECT * FROM BankDetails WHERE accountno = ?";
		con = BankDB.getConnection();
		preparedStatement = con.prepareStatement(query);
		preparedStatement.setLong(1, accNo);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			bank.setName(resultSet.getString(1));
			bank.setAccNo(resultSet.getLong(2));
			bank.setPin(resultSet.getInt(3));
			bank.setAddress(resultSet.getString(4));
			bank.setPhone(resultSet.getString(5));
			bank.setBalance(resultSet.getInt(6));
		} else {
			bank = null;
		}
		return bank;
	}

	/*
	 * Setter for Transaction
	 */
	@Override
	public void setTransactions(BankTransaction trans) throws ClassNotFoundException, SQLException {
		String query = "INSERT INTO transactions VALUES(?,?,?,?)";
		con = BankDB.getConnection();
		preparedStatement = con.prepareStatement(query);
		preparedStatement.setString(1, trans.getType());
		preparedStatement.setLong(2, trans.getAccNo());
		preparedStatement.setInt(3, trans.getAmount());
		preparedStatement.setInt(4, trans.getTransactionId());
		int res = preparedStatement.executeUpdate();
		if (res == 0) {
			System.out.println("Cannot insert");
		} else {
			System.out.println("Updated ");
		}
	}

	/*
	 * Getter for Transaction
	 */
	@Override
	public BankTransaction getTransactions(long accNo) throws ClassNotFoundException, SQLException {
		BankTransaction trans = new BankTransaction();
		String query = "SELECT * FROM transactions WHERE accountno = ?";
		con = BankDB.getConnection();
		preparedStatement = con.prepareStatement(query);
		preparedStatement.setLong(1, accNo);
		resultSet = preparedStatement.executeQuery();
		if (resultSet.next()) {
			trans.setType(resultSet.getString(1));
			trans.setAccNo(resultSet.getLong(2));
			trans.setAmount(resultSet.getInt(3));
			trans.setTransactionId(resultSet.getInt(4));
		}
		return trans;
	}
}