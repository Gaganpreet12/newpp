package ui;

import java.sql.SQLException;
import java.util.Scanner;

import bean.BankTransaction;
import exceptions.*;
import service.BankService;
import service.BankServiceI;

public class BankUi {
	static Scanner scanner = new Scanner(System.in);
	static BankTransaction trans = new BankTransaction();
	static BankTransaction trans1 = new BankTransaction();

	public static void main(String[] args) throws AccountNotFoundException, ClassNotFoundException, SQLException {

		/*
		 * Variables
		 */
		long accNo, accNo1;
		int withdrawAmount, depositAmount = 0, transferAmount = 0;
		int pin, amount, balance;
		boolean res = false;
		String proceed = "yes";

		BankServiceI service = new BankService();

		/*
		 * To ask choice from user and perform particular action
		 */
		while (proceed.equalsIgnoreCase("yes")) {
			switch (menu()) {

			/*
			 * Create Account
			 */
			case 1:

				System.out.print("Enter name: ");
				String name = scanner.nextLine();
				name += scanner.nextLine();

				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {

					System.out.println("Invalid Format");
					System.out.print("Enter name: ");
					name = scanner.next();
				}

				System.out.print("Enter address: ");
				String add = scanner.next();
				add += scanner.nextLine();

				while (!add.matches(regexUserName)) {
					System.out.println("Invalid Format");
					System.out.print("Enter address: ");
					add = scanner.nextLine();

				}

				System.out.println("Enter phone number");
				String phone = scanner.next();
				String phone_format = ("[6-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be 0f 10 digits");
						System.out.print("Enter phone number: ");
						phone = scanner.next();
					}
					System.out.println("Phone number should start from 6");
					System.out.print("Enter phone number: ");
					phone = scanner.next();
				}

				accNo = Long.parseLong(phone) - 10000;

				System.out.print("Enter PIN: ");
				pin = scanner.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin number should be of 4 digits");
					System.out.print("Enter PIN");
					pin = scanner.nextInt();
				}

				System.out.print("Enter Balance: ");
				int bal = scanner.nextInt();

				while (bal < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.print("Enter Balance: ");
					bal = scanner.nextInt();

				}
				try {
					res = service.createAccount(name, add, accNo, phone, pin, bal);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}

				if (res == true) {
					System.out.println("Account Created Successfully !!!");
					System.out.println("Account Number: " + accNo);

					int trans_id = ((int) Math.random() * 1000 + 1000);
					trans.setAccNo(accNo);
					trans.setType("Create");
					trans.setAmount(bal);
					trans.setTransactionId(trans_id);

					service.setTransactions(trans);

				} else {

					System.out.println("Cannot Create Account");
				}

				break;

			/*
			 * Show Balance
			 */
			case 2:

				System.out.print("Enter account number: ");
				accNo = scanner.nextLong();

				try {
					balance = service.showBalance(accNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance:" + balance);

				break;

			/*
			 * Deposit
			 */
			case 3:

				System.out.print("Enter account no: ");
				accNo = scanner.nextLong();

				System.out.print("Enter amount to be deposited: ");
				depositAmount = scanner.nextInt();

				try {
					amount = service.deposit(accNo, depositAmount);
					balance = service.showBalance(accNo);
				}
				catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount Deposited: " + depositAmount);
				System.out.println("Updated Balance: " + balance);
				int trans_id = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accNo);
				trans.setType("Deposit");
				trans.setAmount(depositAmount);
				trans.setTransactionId(trans_id);
				service.setTransactions(trans);

				break;

			/*
			 * Withdraw
			 */
			case 4:

				System.out.print("Enter account no: ");
				accNo = scanner.nextLong();

				System.out.print("Enter amount to withdraw: ");
				withdrawAmount = scanner.nextInt();

				try {
					amount = service.withdraw(accNo, withdrawAmount);
					res = service.validateBalance(accNo, withdrawAmount);
					balance = service.showBalance(accNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("Amount Withdrawn : " + withdrawAmount);
				System.out.println("Updated Balance : " + balance);

				int trans_id1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accNo);
				trans.setType("Withdraw");
				trans.setAmount(withdrawAmount);
				trans.setTransactionId(trans_id1);
				service.setTransactions(trans);

				break;

			/*
			 * Fund Transfer
			 */
			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.print("Enter account no: ");
				accNo = scanner.nextLong();

				System.out.print("Enter account to which you want to transfer fund: ");
				accNo1 = scanner.nextLong();

				System.out.print("Enter amount to transfer: ");
				transferAmount = scanner.nextInt();

				try {
					res = service.validateBalance(accNo, transferAmount);
					res = service.transferfund(accNo, accNo1, transferAmount);

					senders_balance = service.showBalance(accNo);
					recievers_balance = service.showBalance(accNo1);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Amount transferred Successfully");
				System.out.println("Updated balance for Account " + accNo + " : " + senders_balance);
				System.out.println("Updated balance for Account " + accNo1 + " : " + recievers_balance);

				int trans_id_1 = ((int) Math.random() * 1000 + 1000);
				trans.setAccNo(accNo);
				trans.setType("Transfer");
				trans.setAmount(transferAmount);
				trans.setTransactionId(trans_id_1);
				service.setTransactions(trans);

				int trans_id_2 = ((int) Math.random() * 1000 + 1000);
				trans1.setAccNo(accNo1);
				trans1.setType("Transfer");
				trans1.setAmount(transferAmount);
				trans1.setTransactionId(trans_id_2);
				service.setTransactions(trans1);

				break;

			/*
			 * Show Transactions
			 */
			case 6:

				System.out.print("Enter account number: ");
				accNo = scanner.nextLong();
				trans = service.getTransactions(accNo);
				if (trans == null) {
					throw new AccountNotFoundException();
				} else {
					System.out.println("***********Transactions***********");
					System.out.println("Transaction type: " + trans.getType());
					System.out.println("Transaction ID: " + trans.getTransactionId());
					System.out.println("Transaction Account: " + trans.getAccNo());
					System.out.println("Transaction Amount: " + trans.getAmount());
				}

				/*
				 * Exit
				 */
			case 7:
				System.exit(0);
				proceed = "no";
				break;

			default:
				System.out.println("Please Enter choice between 1 - 7 ");
				menu();
			}
		}
	}

	/*
	 * Options Menu
	 */
	public static int menu() {
		System.out.println("**************Welcome to XYZ Wallet**************");
		System.out.println("\t 1. Create Account");
		System.out.println("\t 2. Show Balance");
		System.out.println("\t 3. Deposit");
		System.out.println("\t 4. Withdraw");
		System.out.println("\t 5. Transer Fund");
		System.out.println("\t 6. Print Transcations");
		System.out.println("\t 7. Exit");
		System.out.println("*************************************************");
		System.out.print("Enter Choice: ");
		int choice = scanner.nextInt();
		String s = Integer.toString(choice);
		String pattern = ("[0-7]{1}");
		while (!s.matches(pattern)) {
			System.out.println("Invalid Chice");
			System.out.print("Enter Choice: ");
			choice = scanner.nextInt();
		}
		return choice;
	}
}